
package com.mycompany.mavenproject1;

public class Mavenproject1 {

    public static void main(String[] args) {
        System.out.println("joo osama");
    }
}
